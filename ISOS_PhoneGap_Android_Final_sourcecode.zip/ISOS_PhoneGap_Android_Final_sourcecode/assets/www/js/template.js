
//login header template

window.loginHeaderTmpl = '<div id="LoginHeader">'+
                '<label id="Controltxt">Control</label><label id="Riskstxt">Risks</label>'+
                '<label> 12-12-2012</label>'+
                  '<label id="internationaltxt">International</label><br/>'+
				  '<label id="SOStxt">SOS</label>'+
            '</div>';
            
//video template
window.videoTmpl = '<div id="videotour">'+
                    '<!--<video src="video.mp4" controls="true" type="video/mp4">-->'+
                    '<div  id="videoplay" style="border:1px solid black; background:black; height:120px;padding-top:48px">'+
                    '<img src="images/play.png" onclick="playVideo()"/></div>'+
                  '<br/>'+
                  '<label>Play video to learn more about International SOS Membership App</label>'+
                 ' </div> ';
 //login template             
window.loginFormTmpl =                '  <div id="LoginContent">'+
                   ' <div>'+
                       ' <label>Please enter your International SOS Membership Number provided by your organizatioin </label>'+
                       ' <input type="text" placeholder="Enter Member No." id="membership_id" required value="androidtest" />'+
                    '</div>'+
                    '<div id="rememberme">'+
                        '<input type="checkbox" id="remembermecheckbox"/>'+
                       ' <label>Remember Me</label>'+
                        '<br/>'+
                  '  </div>'+
                    '<div id="btnloginhelp">'+
                        '<button id="loginBtn" onclick="loginBtnEvent()">Login</button>'+
                        '<button id="helpBtn" onclick="helpBtnEvent()">Help</button>'+
                    '</div>'+
                 ' </div> ';
 
 
//dashboard template 
var externalLink="http://mobile.usablenet.com/mt/www.internationalsos.com/MasterPortal/default.aspx?templatemembnum=11BWEB000048&membnum=14AYCA000033&membershiptype=comp&content=landing&countryid=111";

window.dashBoardTmpl =  ' <div id="LoginHeader">'+
                	'<label id="Controltxt">Control</label><label id="Riskstxt">Risks</label>'+
                	'<label id="internationaltxt">International</label><br/>'+
				  	'<label id="SOStxt">SOS</label>'+
                  '</div>'+
                '<table id="changelocation">'+
               ' <tr>'+
              ' <td><img src="" style="width:1px;"/>&nbsp;</td>'+
               '  <td> <label  id="smalltext">We have detected Youre in</label> <br/> '+
                	 '<label id="countryName"></label></td>'+
               ' <td  onClick="customAlert(\'This feature is coming soon\')">CHANGE<br/>LOCATION</td>'+
               ' <td><img src="images/changelocationarrow.png" /></td>'+
                '</tr>'+
               ' </table>'+
               ' <div id="dashboarditems">'+
	                '<ul id="AlertsGuides" >'+
		               ' <li><a href="#/alertIn"><img src="images/alert.png" />'+
		                	'<br/>'+
		                	'<label>ALERTS</label></a>'+
		               ' </li>'+
		               ' <li>'+
		                	'<a href="#" onClick="getExternalLink(externalLink)"> <img src="images/guide.png" />'+
		                	'<br/>'+
		                	'<label>GUIDES</label>'+
		                    '</a>'+
		                '</li>'+
	                '</ul>'+
                '<ul id="CheckinClinic">'+
                '<li>'+
                '<a href="#/checkIn"><img src="images/checkin.png" />'+
                '<br/>'+
                '<label>CHECK IN</label></a>'+
                '</li>'+
                '<li>'+
                '<a href="#" onClick="getExternalLink(externalLink)">'+
                '<img src="images/clinic.png" />'+
                '<br/>'+
                '<label>CLINICS</label>'+
                '</a>'+
                '</li>'+
                '</ul>'+
                '</div>'+
                '<div data-role="footer" data-position="fixed" data-iconpos="top" class="ui-footer ui-bar-a ui-footer-fixed slideup" role="contentinfo">'+
                '<div data-role="navbar" role="navigation" class="ui-navbar ui-mini">'+
                '<ul class="ui-grid-d">'+
                '<li class="ui-block-a"><a href="#" onClick="customAlert(\'This feature is coming soon\')" data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-theme="a" data-inline="true" class="ui-btn ui-btn-up-a ui-btn-inline"><span class="ui-btn-inner"><span class="ui-btn-text"><img src="images/location.png"> <br>Location</span></span></a></li>'+
                '<li class="ui-block-b"><a href="#" onClick="customAlert(\'This feature is coming soon\')" data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-theme="a" data-inline="true" class="ui-btn ui-btn-up-a ui-btn-inline"><span class="ui-btn-inner"><span class="ui-btn-text"><img src="images/globalpulse.png"> <br> Global Pulse</span></span></a></li>'+
                '<li class="ui-block-c"><a href="#" onClick="customAlert(\'This feature is coming soon\')" data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-theme="a" data-inline="true" class="ui-btn ui-btn-up-a ui-btn-inline"><span class="ui-btn-inner"><span class="ui-btn-text"><img src="images/call.png"><br> Call Us</span></span></a></li>'+
                '<li class="ui-block-d"><a href="#" onClick="customAlert(\'This feature is coming soon\')" data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-theme="a" data-inline="true" class="ui-btn ui-btn-up-a ui-btn-inline"><span class="ui-btn-inner"><span class="ui-btn-text"><img src="images/settings.png"><br>Settings</span></span></a></li>'+
                '<li class="ui-block-e"><a href="#" onClick="customAlert(\'This feature is coming soon\')" data-corners="false" data-shadow="false" data-iconshadow="true" data-wrapperels="span" data-theme="a" data-inline="true" class="ui-btn ui-btn-up-a ui-btn-inline"><span class="ui-btn-inner"><span class="ui-btn-text"><img src="images/more.png"><br>More</span></span></a></li>'+
                '</ul>'+
                '</div><!-- /navbar -->'+
                '</div> ';

//alert Template
window.alertInTmpl = '<section data-role="header" data-position="inline" >'+
                '<div id="CheckinHeader">'+
                    '<a onclick="window.history.back()">'+
                        '<div class="backbutton" >'+
                            '<div>'+
                               ' <span></span>'+
                            '</div>'+
                           ' <p class="backb">Back</p>'+
                        ' </div>'+
                   ' </a>'+
                  '<p>Alerts</p>'+  
                '</div>'+
            '</section>'+
            <!-- End Header -->
            <!-- Begin Main Content -->
            '<div class="content-primary" id="alertWrapper">'+
                '<ul data-role="listview" id="datalist" style="margin-left:0px;">'+
               ' </ul>'+
           ' </div>';
           
           
           
//checkIn template                
window.checkInTmpl =  '<section data-role="header" data-position="inline" >'+
           ' <div id="CheckinHeader">'+
              '  <a onclick="window.history.back()">'+
                   ' <div class="backbutton">'+
                      '  <div>'+
                          '  <span></span>'+
                        '</div>'+
                        '<p class="backb">Back</p>'+
                    '</div>'+
               ' </a>'+
                '<p>Check In</p>'+
           ' </div>'+
        '</section>'+
        <!-- End Header -->
        <!-- Begin Main Content -->
        <!-- Map Content -->
       ' <div>'+
           
          '<div id="map_canvas" style="height:200px"></div>'+

        '</div>'+
        '<div id="CheckinLocationDetails">'+
          
          '<div id="locationHeader">'+
             ' <h1>Location</h1>'+
               ' <label id="country"></label><br/>'+
                'Latitude: <label id="latitudeValue"> </label><br/>'+
                'Longitude: <label id="longitudeValue"></label>'+
          '</div>'+
          
       ' <div id="btnCheckIn">'+
           ' <a onclick="onCheckInClick()">Check In Here</a>'+
        '</div>';

//check in sucessful template
window.checkinSuccessfulTmpl = '<div  id="CheckinSuccessful">'+
                '<img src="images/check.png" />'+
                '<p> <b>You \'ve successfully checked in.</b></p>'+
                '<a onclick="successCheckIn()">Done</a>'+
                '</div> ';       

            
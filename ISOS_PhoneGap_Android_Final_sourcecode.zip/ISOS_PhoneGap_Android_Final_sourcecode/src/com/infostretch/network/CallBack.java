package com.infostretch.network;


public class CallBack {

	private String UserName;
	private String DeviceToken;
	private String Latitude;
	private String Longitude;
	private String StatusCode;
	private String StatusMessage;
	private String Password;
	private String DeviceType;
	private boolean Flag;
	private String Method;
	private long timestamp;
	
	public String getDeviceType() {
		return DeviceType;
	}
	public void setDeviceType(String deviceType) {
		DeviceType = deviceType;
	}
	private String Category;
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		this.Category = category;
	}
	public String getLabel() {
		return Label;
	}
	public void setLabel(String label) {
		this.Label = label;
	}
	public String getEvent() {
		return Action;
	}
	public void setEvent(String event) {
		this.Action = event;
	}
	public String getValue() {
		return Value;
	}
	public void setValue(String value) {
		this.Value = value;
	}
	private String Label;
	private String Action;
	private String Value;
	public String getMembershipID() {
		return UserName;
	}
	public void setMembershipID(String membershipID) {
		this.UserName = membershipID;
	}
	public String getDeviceToken() {
		return DeviceToken;
	}
	public void setDeviceToken(String deviceToken) {
		this.DeviceToken = deviceToken;
	}
	public String getLatitude() {
		return Latitude;
	}
	public void setLatitude(String latitude) {
		this.Latitude = latitude;
	}
	public String getLongitude() {
		return Longitude;
	}
	public void setLongitude(String longitude) {
		this.Longitude = longitude;
	}
	public String getStatusCode() {
		return StatusCode;
	}
	public void setStatusCode(String statusCode) {
		StatusCode = statusCode;
	}
	public String getStatusMessage() {
		return StatusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		StatusMessage = statusMessage;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public void setFlag(boolean flag) {
		Flag = flag;
	}
	public boolean isFlag() {
		return Flag;
	}
	public void setMethod(String method) {
		Method = method;
	}
	public String getMethod() {
		return Method;
	}
	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}
	public long getTimestamp() {
		return timestamp;
	}

	
}

package com.infostretch.network;

public class WebResponse {

	private String StatusMessage;
	private String	StausCode;
	public void setStatusMessage(String statusMessage) {
		StatusMessage = statusMessage;
	}
	public String getStatusMessage() {
		return StatusMessage;
	}
	public void setStausCode(String stausCode) {
		StausCode = stausCode;
	}
	public String getStausCode() {
		return StausCode;
	}
}

package com.infostretch.isos.app;

import android.app.Application;

public class ISOSApp extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
		ISOSContext.setContext(getApplicationContext());
	}

}
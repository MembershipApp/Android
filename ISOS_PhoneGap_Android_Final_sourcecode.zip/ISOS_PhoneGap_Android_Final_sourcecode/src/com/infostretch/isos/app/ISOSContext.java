package com.infostretch.isos.app;

import android.content.Context;

public class ISOSContext {
	
	private static Context context;

	public static void setContext(Context context) {
		ISOSContext.context = context;
	}

	public static Context getContext() {
		return context;
	}

}


package com.infostretch.location;

/**
 * Called before and after AsyncTask call........
 * 
 * @author dinesh.prajapati
 */
public interface ServiceInterface {

	/**
	 * called after the completion of AsyncTask.
	 * 
	 * @param data
	 *            returned from AsyncTask call.
	 */
	public abstract void onComplete(Object data);
}

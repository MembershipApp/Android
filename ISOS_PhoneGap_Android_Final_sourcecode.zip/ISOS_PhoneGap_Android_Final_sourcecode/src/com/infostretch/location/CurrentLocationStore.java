package com.infostretch.location;


public class CurrentLocationStore {
	private String Latitude; 
	private String Longitude;
	private String Accuracy;
	private String Country;
	private String State;
	private String City;
	private String Street_Address;
	private String Street_Address1;
	public static CurrentLocationStore currentLocationStore;

	public static CurrentLocationStore getInstance() {
		if (currentLocationStore == null) {
			currentLocationStore = new CurrentLocationStore();
		}
		return currentLocationStore;
	}

	public String getLatitude() {
		return Latitude;
	}

	public String getAccuracy() {
		return Accuracy;
	}

	public void setAccuracy(String accuracy) {
		Accuracy = accuracy;
	}

	public void setLatitude(String latitude) {
		Latitude = latitude;
	}

	public String getLongitude() {
		return Longitude;
	}

	public void setLongitude(String longitude) {
		Longitude = longitude;
	}

	public void setCountry(String country) {
		Country = country;
	}

	public String getCountry() {
		return Country;
	}

	public void setState(String state) {
		State = state;
	}

	public String getState() {
		return State;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getCity() {
		return City;
	}

	public void setStreetAddress(String street) {
		Street_Address = street;
	}

	public String getStreetAddress() {
		return Street_Address;
	}

	public void setStreetAddress1(String street1) {
		Street_Address1 = street1;
	}

	public String getStreetAddress1() {
		return Street_Address1;
	}
}
